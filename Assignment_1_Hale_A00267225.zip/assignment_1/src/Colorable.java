//  Weston Hale
//  A00267225
//  March 15th, 2024
//  Assigment 1 Program

package src;

/**
 * Tells the user how to color the object.
 * @return String: Description on how to color.
 */
public interface Colorable {
    String howToColor();
}
