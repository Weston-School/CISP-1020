//  Weston Hale
//  A00267225
//  March 27th, 2024
//  QuadraticTester

public class NanException extends Exception { 
    public NanException(String errorMessage) {
        super(errorMessage);
    }
}