//  Weston Hale
//  A00267225
//  Feb 28th, 2024
//  Taxable Tester Program

public interface Taxable {

    double getTaxable();
    
} 
